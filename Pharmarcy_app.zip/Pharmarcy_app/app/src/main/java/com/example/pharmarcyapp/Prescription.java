package com.example.pharmarcyapp;


import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Prescription extends AppCompatActivity {

    private TextView textView;
    private EditText medicationNameEditText;
    private EditText dosageEditText;
    private EditText instructionsEditText;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescriptions);

        // Initialize views
        textView = findViewById(R.id.textView);
        medicationNameEditText = findViewById(R.id.medication_name_edit_text);
        dosageEditText = findViewById(R.id.dosage_edit_text);
        instructionsEditText = findViewById(R.id.instructions_edit_text);
        submitButton = findViewById(R.id.submit_button);

        // Set onClick listener for submit button (if needed)
        submitButton.setOnClickListener(view -> {
            // Perform actions when submit button is clicked
            // For example, you can retrieve text from EditText fields
            String medicationName = medicationNameEditText.getText().toString();
            String dosage = dosageEditText.getText().toString();
            String instructions = instructionsEditText.getText().toString();

            // Do something with the retrieved information (e.g., submit to a database)
        });
    }
}
